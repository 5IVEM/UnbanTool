if you are need help connect us 
alikanek#1337
https://discord.gg/6g4YBu